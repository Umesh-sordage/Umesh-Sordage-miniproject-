from django.http import HttpResponseRedirect
from django.shortcuts import render

# Create your views here.
from .forms import ProductDetails
from .models import Product


def add_show(request):
    if request.method == 'POST':
        fm = ProductDetails(request.POST)
        if fm.is_valid():
            pid = fm.cleaned_data['Prodid']
            pnm = fm.cleaned_data['Prodname']
            pw1 = fm.cleaned_data['Prodtype1']
            pr = fm.cleaned_data['Price']
            pw2 = fm.cleaned_data['Prodtype2']
            reg = Product(Prodid=pid, Prodname=pnm, Prodtype1=pw1,Price=pr, Prodtype2=pw2 )
            reg.save()
            fm = ProductDetails() #used for blank form after saving data. form=fm
    else:
        fm = ProductDetails()
    stud = Product.objects.all()
    return render(request, 'Dmart/add.html', {'form':fm, 'stu':stud})
#edit and update function
def update_data(request,id):
    # if data is coming from post method then it will be saved otherwise data goes in else part their is no save method present
    if request.method == 'POST':
        pi = Product.objects.get(pk=id)
        fm = ProductDetails(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
        return HttpResponseRedirect('/')
    else:
        pi = Product.objects.get(pk=id)
        fm = ProductDetails(instance=pi)
    return render(request,'Dmart/update.html', {'form':fm})
#delete function
def delete_data(request,id):
    if request.method == 'POST':
        pi = Product.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')

