from django import forms

from django.core import validators

from .models import Product


class ProductDetails(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['Prodid', 'Prodname', 'Prodtype1', 'Price', 'Prodtype2']
        widgets = {
            'Prodid': forms.TextInput(attrs={'class': 'form-control'}),
            'Prodname': forms.TextInput(attrs={'class': 'form-control'}),
            'Prodtype1': forms.TextInput(attrs={'class': 'form-control'}),
            'Price': forms.TextInput(attrs={'class': 'form-control'}),
            'Prodtype2': forms.TextInput(attrs={'class': 'form-control'}),
        }

